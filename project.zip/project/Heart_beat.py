import numpy as np
import pandas as pd
import os
m = pd.read_csv("mitbih_train.csv", header=None)
def check():
    n=float(input("Enter the ECG Pulse:-"))
    for i in range(1,188):
        y=max(m[i])
    z=0.3

    if n>(y/2):
        print("Cool Down buddy!You were getting hot")
    elif n<z:
        print("Dehyadration level,Please drink ORS")
    else:
        print("You were alright")
        pass
