from keras.preprocessing.image import img_to_array
import cv2
from keras.models import load_model
import numpy as np
import webbrowser
from nltk.chat.util import Chat, reflections


def emotion(faces1):
    # parameters for loading data and images
    detection_model_path = 'haarcascade_frontalface_default.xml'
    emotion_model_path = '_mini_XCEPTION.102-0.66.hdf5'

    # hyper-parameters for bounding boxes shape
    # loading models
    face_detection = cv2.CascadeClassifier(detection_model_path)
    emotion_classifier = load_model(emotion_model_path, compile=False)
    EMOTIONS = ["angry" ,"disgust","scared", "happy", "sad", "surprised","neutral"]

    gray = cv2.cvtColor(faces1, cv2.COLOR_BGR2GRAY)
    faces = face_detection.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(30,30),flags=cv2.CASCADE_SCALE_IMAGE)
    
    canvas = np.zeros((250, 300, 3), dtype="uint8")
    if len(faces) > 0:
        faces = sorted(faces, reverse=True,
        key=lambda x: (x[2] - x[0]) * (x[3] - x[1]))[0]
        (fX, fY, fW, fH) = faces
        roi = gray[fY:fY + fH, fX:fX + fW]
        roi = cv2.resize(roi, (64, 64))
        roi = roi.astype("float") / 255.0
        roi = img_to_array(roi)
        roi = np.expand_dims(roi, axis=0)
        
        
        preds = emotion_classifier.predict(roi)[0]
        emotion_probability = np.max(preds)
        label = EMOTIONS[preds.argmax()]
#angry comment
    if label == "angry":
        print("Calm Down!!! You Look Angry please talk to me")
        
        pairs = [
        [
        r"my name is (.*)",
        ["Hello %1, Keep calm",]
        ],
        [
        r"what is your name ?",
        ["My name is Chatty and I'm a chatbot ?",]
        ],
        [
        r"how are you ?",
        ["I'm doing good\nHow about You ?",]
        ],
        [
        r"sorry (.*)",
        ["Its alright","Its OK, never mind",]
        ],
        [
        r"i am angry",
        ["ohh why",]
        ],
        [
        r"hi|hey|hello",
        ["Hello", "Hey there",]
        ],
        [
        r"(.*) age?",
        ["I'm a computer program dude\nSeriously you are asking me this?",]
        
        ],
        [
        r"please make me cool ?",
        ["just keep patience everything will be alright",]
        
        ],
        [
        r"angry",
        ["Please be happy and have afaith in god",]
        ],
        [
        r"(.*) (location|city) ?",
        ['Chennai, Tamil Nadu',]
        ],
        [
        r"how is weather in (.*)?",
        ["Weather in %1 is awesome like always","Too hot man here in %1","Too cold man here in %1","Never even heard about %1"]
        ],
        [
        r"i work in (.*)?",
        ["%1 is an Amazing company, I have heard about it. But they are in huge loss these days.",]
        ],
        [
        r"(.*)raining in (.*)",
        ["No rain since last week here in %2","Damn its raining too much here in %2"]
        ],
        [
        r"how (.*) health(.*)",
        ["I'm a computer program, so I'm always healthy ",]
        ],
        [
        r"(.*) (sports|game) ?",
        ["I'm a very big fan of Football",]
        ],
        [
        r"who (.*) sportsperson ?",
        ["Messy","Ronaldo","Roony"]
        ],
        [
        r"who (.*) (moviestar|actor)?",
        ["Brad Pitt"]
        ],
        [
        r"quit",
        ["BBye take care. See you soon :) ","It was nice talking to you. See you soon :) press 1 for adventure"]
        ],
        ]
        def chatty():
            print("PRESS 1 I HAVE SOMETHING FOR U ") #default message at the start
        chat = Chat(pairs, reflections)
        chat.converse()
        if __name__ == "__main__":
            
             chatty()
        ent = int(input())
        if ent == 1:
            text="Love song"
            webbrowser.open("https://www.youtube.com/results?search_query="+text+"")
        else : pass

    elif label == "sad":
        print("Calm Down!!! You Look Sad let's talk to me")
        pairs = [
        [
        r"my name is (.*)",
        ["Hello %1, Don't be sad",]
        ],
        [
        r"what is your name ?",
        ["My name is Chatty and I'm a chatbot ?",]
        ],
        [
        r"how are you ?",
        ["I'm doing good\nHow about You ?",]
        ],
        [
        r"sorry (.*)",
        ["Its alright","Its OK, never mind",]
        ],
        [
        r"sad",
        ["please don't be sad, be happy",]
        ],
        [
        r"hi|hey|hello",
        ["Hello", "Hey there",]
        ],
        [
        r"(.*) age?",
        ["I'm a computer program dude\nSeriously you are asking me this?",]
        
        ],
        [
        r"how can you help me",
        ["by make laughing you",]
        
        ],
        [
        r"(.*) created ?",
        ["Nagesh created me using Python's NLTK library ","top secret ;)",]
        ],
        [
        r"(.*) (location|city) ?",
        ['Chennai, Tamil Nadu',]
        ],
        [
        r"how is weather in (.*)?",
        ["Weather in %1 is awesome like always","Too hot man here in %1","Too cold man here in %1","Never even heard about %1"]
        ],
        [
        r"i work in (.*)?",
        ["%1 is an Amazing company, I have heard about it. But they are in huge loss these days.",]
        ],
        [
        r"(.*)raining in (.*)",
        ["No rain since last week here in %2","Damn its raining too much here in %2"]
        ],
        [
        r"how (.*) health(.*)",
        ["I'm a computer program, so I'm always healthy ",]
        ],
        [
        r"(.*) (sports|game) ?",
        ["I'm a very big fan of Football",]
        ],
        [
        r"who (.*) sportsperson ?",
        ["Messy","Ronaldo","Roony"]
        ],
        [
        r"who (.*) (moviestar|actor)?",
        ["Brad Pitt"]
        ],
        [
        r"quit",
        ["BBye take care. See you soon :) Press 1 for refreshment","It was nice talking to you. See you soon :) Press 1 for refreshment"]
        ],
        ]
        def chatty():
             print("Hi, press 1 to be happy ") #default message at the start
        chat = Chat(pairs, reflections)
        chat.converse()
        if __name__ == "__main__":
            
            chatty()

            ent = int(input())
            if ent == 1:
                 text="Kapil sharma show"
                 webbrowser.open("https://www.youtube.com/results?search_query="+text+"") 
            else : pass
    elif label == "scared":
        
        print("Calm Down!!! You Look Scared.talk to me for a while")
        pairs = [
        [
        r"my name is (.*)",
        ["Hello %1, be brave ?",]
        ],
        [
        r"what is your name ?",
        ["My name is Chatty and I'm a chatbot ?",]
        ],
        [
        r"how are you ?",
        ["I'm doing good\nHow about You ?",]
        ],
        [
        r"sorry (.*)",
        ["Its alright","Its OK, never mind",]
        ],
        [
        r"scared",
        ["be brave brotha",]
        ],
        [
        r"hi|hey|hello",
        ["Hello", "Hey there",]
        ],
        [
        r"(.*) age?",
        ["I'm a computer program dude\nSeriously you are asking me this?",]
        
        ],
        [
        r"help me",
        ["sure",]
        
        ],
        [
        r"(.*) created ?",
        ["Nagesh created me using Python's NLTK library ","top secret ;)",]
        ],
        [
        r"(.*) (location|city) ?",
        ['Chennai, Tamil Nadu',]
        ],
        [
        r"how is weather in (.*)?",
        ["Weather in %1 is awesome like always","Too hot man here in %1","Too cold man here in %1","Never even heard about %1"]
        ],
        [
        r"i work in (.*)?",
        ["%1 is an Amazing company, I have heard about it. But they are in huge loss these days.",]
        ],
        [
        r"(.*)raining in (.*)",
        ["No rain since last week here in %2","Damn its raining too much here in %2"]
        ],
        [
        r"how (.*) health(.*)",
        ["I'm a computer program, so I'm always healthy ",]
        ],
        [
        r"(.*) (sports|game) ?",
        ["I'm a very big fan of Football",]
        ],
        [
        r"who (.*) sportsperson ?",
        ["Messy","Ronaldo","Roony"]
        ],
        [
        r"who (.*) (moviestar|actor)?",
        ["Brad Pitt"]
        ],
        [
        r"quit",
        ["BBye take care. See you soon :) Press 1 for refreshment","It was nice talking to you. See you soon :) Press 1 for refreshment"]
        ],
        ]
        def chatty():
            print("press 1 i have something for u ") #default message at the start
        chat = Chat(pairs, reflections)
        chat.converse()
        if __name__ == "__main__":
            
             chatty()

             ent = int(input())
             if ent == 1:
                 text="Hanuman Chalisa"
                 webbrowser.open("https://www.youtube.com/results?search_query="+text+"")
             else : pass


                

