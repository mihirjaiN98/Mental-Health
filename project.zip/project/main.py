import Heart_beat as hb
from emotion import emotion 
import cv2

print("Check mental health through \n 1. Heart Beats \n 2. Body monitoring")
choice = int(input("Enter your choice here:-"))
if choice == 1:
    hb.check()
elif choice == 2:
    filename=input("Enter the Image Name:-")
    face=cv2.imread(filename)
    emotion(face)
else :
    print("Wrong Choice")